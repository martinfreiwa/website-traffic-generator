from sqlalchemy import Column, Integer, String, ForeignKey, DateTime, Boolean, JSON, Float, Text
from sqlalchemy.orm import relationship
from database import Base
import datetime
import uuid

def generate_uuid():
    return str(uuid.uuid4())

class User(Base):
    __tablename__ = "users"

    id = Column(String, primary_key=True, default=generate_uuid)
    email = Column(String, unique=True, index=True)
    password_hash = Column(String)
    role = Column(String, default="user") # 'user', 'admin'
    balance = Column(Float, default=0.00)
    api_key = Column(String, unique=True, nullable=True)
    
    # Affiliate Info
    affiliate_code = Column(String, unique=True, nullable=True)
    referred_by = Column(String, ForeignKey("users.id"), nullable=True)
    
    status = Column(String, default="active") # 'active', 'suspended'
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    
    # Extended Profile
    phone = Column(String, nullable=True)
    company = Column(String, nullable=True)
    vat_id = Column(String, nullable=True)
    address = Column(String, nullable=True)
    city = Column(String, nullable=True)
    country = Column(String, nullable=True)

    projects = relationship("Project", back_populates="user")
    transactions = relationship("Transaction", back_populates="user")
    # Self-referential relationship for affiliates
    referrer = relationship("User", remote_side=[id], backref="referrals")

class AffiliateEarnings(Base):
    __tablename__ = "affiliate_earnings"

    id = Column(String, primary_key=True, default=generate_uuid)
    referrer_id = Column(String, ForeignKey("users.id"))
    referee_id = Column(String, ForeignKey("users.id")) # The user who bought creates
    transaction_id = Column(String, ForeignKey("transactions.id"))
    amount = Column(Float)
    status = Column(String, default="pending") # 'pending', 'paid'
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

class Project(Base):
    __tablename__ = "projects"

    id = Column(String, primary_key=True, default=generate_uuid)
    user_id = Column(String, ForeignKey("users.id"))
    name = Column(String, index=True)
    status = Column(String, default="active") # 'active', 'stopped', 'completed'
    plan_type = Column(String, default="Custom")
    
    # High Level Constraints (for easy querying without parsing JSON)
    daily_limit = Column(Integer, default=0)
    total_target = Column(Integer, default=0)
    hits_today = Column(Integer, default=0)
    total_hits = Column(Integer, default=0)
    expires_at = Column(DateTime, nullable=True)
    
    # THE CORE CONFIG
    # Stores the full ProjectSettings object from frontend
    settings = Column(JSON, nullable=False) 
    
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    
    user = relationship("User", back_populates="projects")
    traffic_logs = relationship("TrafficLog", back_populates="project")

class Transaction(Base):
    __tablename__ = "transactions"

    id = Column(String, primary_key=True, default=generate_uuid)
    user_id = Column(String, ForeignKey("users.id"))
    type = Column(String) # 'credit', 'debit', 'bonus'
    amount = Column(Float)
    description = Column(String, nullable=True)
    status = Column(String, default="completed")
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    
    user = relationship("User", back_populates="transactions")

class Proxy(Base):
    __tablename__ = "proxies"

    id = Column(Integer, primary_key=True, index=True)
    url = Column(String) # e.g. http://user:pass@host:port
    country = Column(String, nullable=True)
    state = Column(String, nullable=True)
    city = Column(String, nullable=True)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

class TrafficLog(Base):
    __tablename__ = "traffic_log"

    id = Column(Integer, primary_key=True, index=True)
    project_id = Column(String, ForeignKey("projects.id"), nullable=True)
    timestamp = Column(DateTime, default=datetime.datetime.utcnow)
    url = Column(String)
    event_type = Column(String) # "hit", "visit"
    status = Column(String) # "success", "failure"
    country = Column(String, nullable=True)
    ip = Column(String, nullable=True)
    proxy = Column(String, nullable=True)
    
    project = relationship("Project", back_populates="traffic_logs")
class Ticket(Base):
    __tablename__ = "tickets"

    id = Column(String, primary_key=True, default=generate_uuid)
    user_id = Column(String, ForeignKey("users.id"))
    subject = Column(String)
    status = Column(String, default="open") # 'open', 'in-progress', 'closed'
    priority = Column(String, default="low") # 'low', 'medium', 'high'
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    messages = Column(JSON, default=[]) # List of {sender: 'user'|'admin', text: str, date: str}

    user = relationship("User", backref="tickets")

class Notification(Base):
    __tablename__ = "notifications"

    id = Column(String, primary_key=True, default=generate_uuid)
    user_id = Column(String, ForeignKey("users.id"))
    title = Column(String)
    message = Column(String)
    type = Column(String, default="info") # 'info', 'success', 'warning', 'error'
    is_read = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

    user = relationship("User", backref="notifications")

class SystemSettings(Base):
    __tablename__ = "system_settings"

    id = Column(Integer, primary_key=True)
    settings = Column(JSON, nullable=False)
    updated_at = Column(DateTime, default=datetime.datetime.utcnow, onupdate=datetime.datetime.utcnow)
