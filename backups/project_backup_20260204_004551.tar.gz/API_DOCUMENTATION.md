# TrafficGen Pro - API Integration Guide

This guide provides the technical documentation needed to integrate TrafficGen Pro into your own website or application using our REST API.

## 🔑 Authentication

All API requests must be authenticated using an API Key.

**Header Name:** `X-API-KEY`  
**Your Key:** `tgp_k7Y2j_JTvu1irFcrMkQeWCrihceaRC_He_UPKqoSh1c`

---

## 📂 Project Management


Projects allow you to set up recurring, scheduled traffic that runs automatically.

### 1. Create a Project
Set up a campaign that distributes visitors evenly over a period of time.

**Endpoint:** `POST /projects`  
**Body (JSON):**
```json
{
    "name": "Daily Organic Growth",
    "daily_limit": 5000,
    "total_target": 150000,
    "settings": {
        "targets": [
            {
                "url": "https://yourwebsite.com/",
                "tid": "G-XXXXXXXXXX"
            }
        ],
        "traffic_source_preset": "organic",
        "device_distribution": {
            "desktop": 70,
            "mobile": 30
        }
    }
}
```

### 2. List Your Projects
Retrieve all your configured projects and their current status.

**Endpoint:** `GET /projects`

### 3. Start/Stop a Project
Manually control a specific project using its ID.

*   **Start:** `POST /projects/{project_id}/start`
*   **Stop:** `POST /projects/{project_id}/stop`

---

## ⚡ Ad-hoc Traffic (Instant Burst)

Use this if you want to trigger traffic immediately without creating a persistent project.

**Endpoint:** `POST /start`  
**Body (JSON):**
```json
{
    "targets": [
        {
            "url": "https://yourwebsite.com/",
            "tid": "G-XXXXXXXXXX"
        }
    ],
    "visitors_per_min": 100,
    "duration_mins": 60,
    "mode": "direct_hit",
    "traffic_source_preset": "social"
}
```

**Stop All Ad-hoc Traffic:** `POST /stop`

---

## 📊 Monitoring & Stats

### 1. Real-time Dashboard Stats
Get the overall success/failure counts for your traffic.

**Endpoint:** `GET /stats`

### 2. Live Log Feed (Admin Only)
See the raw hits being dispatched in real-time.

**Endpoint:** `GET /admin/simulator/status`

---

## 💡 Best Practices for GA4 Visibility

1.  **Measurement ID:** Always ensure the `tid` is a valid GA4 ID starting with `G-`.
2.  **Referrers:** Use `organic` (Google/Bing) or `social` (Facebook/Twitter) presets to ensure traffic doesn't just show up as "Unassigned".
3.  **Distribution:** Use the `device_distribution` setting to match your target audience (e.g., 90% mobile for social media traffic).
4.  **Steady Growth:** For new sites, start with 100-500 visitors/day and scale up slowly to avoid being flagged by anomaly detection.
