import re
from sqlalchemy import Column, Integer, String, ForeignKey, DateTime, Boolean, JSON, Float, Text, event
from sqlalchemy.orm import relationship, validates
from database import Base
import datetime
import uuid

# Email validation regex pattern
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$')

def generate_uuid():
    return str(uuid.uuid4())

class User(Base):
    __tablename__ = "users"

    id = Column(String, primary_key=True, default=generate_uuid)
    email = Column(String, unique=True, index=True)

    @validates('email')
    def validate_email(self, key, email):
        if email is None:
            raise ValueError("Email is required")
        email = email.lower().strip()
        if not EMAIL_REGEX.match(email):
            raise ValueError(f"Invalid email format: {email}")
        return email
    password_hash = Column(String)
    role = Column(String, default="user") # 'user', 'admin'
    balance = Column(Float, default=0.00)
    api_key = Column(String, unique=True, nullable=True)
    
    # Affiliate Info
    affiliate_code = Column(String, unique=True, nullable=True)
    referred_by = Column(String, ForeignKey("users.id"), nullable=True)
    
    status = Column(String, default="active") # 'active', 'suspended'
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    
    # Extended Profile
    name = Column(String, nullable=True)
    phone = Column(String, nullable=True)
    telegram = Column(String, nullable=True)
    company = Column(String, nullable=True)
    vat_id = Column(String, nullable=True)
    address = Column(String, nullable=True)
    city = Column(String, nullable=True)
    zip = Column(String, nullable=True)
    country = Column(String, nullable=True)
    api_access_status = Column(String, default="none") # 'none', 'pending', 'approved', 'rejected'
    api_application_data = Column(JSON, nullable=True) # { usage: str, websites: str, applied_at: str }
    avatar_url = Column(String, nullable=True)
    preferences = Column(JSON, default={
        "campaign_alerts": True,
        "low_balance_warning": True,
        "marketing_emails": False,
        "weekly_reports": True
    })

    projects = relationship("Project", back_populates="user")
    transactions = relationship("Transaction", back_populates="user")
    # Self-referential relationship for affiliates
    referrer = relationship("User", remote_side=[id], backref="referrals")

class AffiliateEarnings(Base):
    __tablename__ = "affiliate_earnings"

    id = Column(String, primary_key=True, default=generate_uuid)
    referrer_id = Column(String, ForeignKey("users.id"))
    referee_id = Column(String, ForeignKey("users.id")) # The user who bought creates
    transaction_id = Column(String, ForeignKey("transactions.id"))
    amount = Column(Float)
    status = Column(String, default="pending") # 'pending', 'paid'
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

class Project(Base):
    __tablename__ = "projects"

    id = Column(String, primary_key=True, default=generate_uuid)
    user_id = Column(String, ForeignKey("users.id"))
    name = Column(String, index=True)
    status = Column(String, default="active") # 'active', 'stopped', 'completed'
    plan_type = Column(String, default="Custom")
    
    # High Level Constraints (for easy querying without parsing JSON)
    daily_limit = Column(Integer, default=0)
    total_target = Column(Integer, default=0)
    hits_today = Column(Integer, default=0)
    total_hits = Column(Integer, default=0)
    expires_at = Column(DateTime, nullable=True)
    
    # THE CORE CONFIG
    # Stores the full ProjectSettings object from frontend
    settings = Column(JSON, nullable=False) 
    
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    
    user = relationship("User", back_populates="projects")
    traffic_logs = relationship("TrafficLog", back_populates="project")

class Transaction(Base):
    __tablename__ = "transactions"

    id = Column(String, primary_key=True, default=generate_uuid)
    user_id = Column(String, ForeignKey("users.id"))
    type = Column(String) # 'credit', 'debit', 'bonus'
    amount = Column(Float)
    description = Column(String, nullable=True)
    status = Column(String, default="completed")
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    
    user = relationship("User", back_populates="transactions")

class Proxy(Base):
    __tablename__ = "proxies"

    id = Column(Integer, primary_key=True, index=True)
    url = Column(String) # e.g. http://user:pass@host:port
    country = Column(String, nullable=True)
    state = Column(String, nullable=True)
    city = Column(String, nullable=True)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

class TrafficLog(Base):
    __tablename__ = "traffic_log"

    id = Column(Integer, primary_key=True, index=True)
    project_id = Column(String, ForeignKey("projects.id"), nullable=True)
    timestamp = Column(DateTime, default=datetime.datetime.utcnow)
    url = Column(String)
    event_type = Column(String) # "hit", "visit", "session_start", "bounce"
    status = Column(String) # "success", "failure"
    country = Column(String, nullable=True)
    ip = Column(String, nullable=True)
    proxy = Column(String, nullable=True)
    # New fields for enhanced analytics
    session_duration = Column(Float, nullable=True)  # Duration in seconds
    pages_viewed = Column(Integer, default=1)
    device_type = Column(String, nullable=True)  # desktop, mobile, tablet
    traffic_source = Column(String, nullable=True)  # organic, social, direct, etc.
    bounced = Column(Boolean, default=False)  # True if visitor bounced
    
    project = relationship("Project", back_populates="traffic_logs")


class ProjectStats(Base):
    """Aggregated statistics for projects - updated hourly"""
    __tablename__ = "project_stats"
    
    id = Column(Integer, primary_key=True, index=True)
    project_id = Column(String, ForeignKey("projects.id"), nullable=False)
    hour = Column(DateTime, nullable=False)  # Hour bucket
    
    # Metrics
    total_visitors = Column(Integer, default=0)
    successful_hits = Column(Integer, default=0)
    failed_hits = Column(Integer, default=0)
    bounce_count = Column(Integer, default=0)
    avg_session_duration = Column(Float, default=0.0)
    
    # Breakdown by device
    desktop_visitors = Column(Integer, default=0)
    mobile_visitors = Column(Integer, default=0)
    tablet_visitors = Column(Integer, default=0)
    
    # Breakdown by source
    organic_visitors = Column(Integer, default=0)
    social_visitors = Column(Integer, default=0)
    direct_visitors = Column(Integer, default=0)
    referral_visitors = Column(Integer, default=0)
    
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
class Ticket(Base):
    __tablename__ = "tickets"

    id = Column(String, primary_key=True, default=generate_uuid)
    user_id = Column(String, ForeignKey("users.id"))
    project_id = Column(String, ForeignKey("projects.id"), nullable=True)
    subject = Column(String)
    status = Column(String, default="open") # 'open', 'in-progress', 'closed'
    priority = Column(String, default="low") # 'low', 'medium', 'high'
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    messages = Column(JSON, default=[]) # List of {sender: 'user'|'admin', text: str, date: str}

    user = relationship("User", backref="tickets")

class Notification(Base):
    __tablename__ = "notifications"

    id = Column(String, primary_key=True, default=generate_uuid)
    user_id = Column(String, ForeignKey("users.id"))
    title = Column(String)
    message = Column(String)
    type = Column(String, default="info") # 'info', 'success', 'warning', 'error'
    is_read = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

    user = relationship("User", backref="notifications")

class SystemSettings(Base):
    __tablename__ = "system_settings"

    id = Column(Integer, primary_key=True)
    settings = Column(JSON, nullable=False)
    updated_at = Column(DateTime, default=datetime.datetime.utcnow, onupdate=datetime.datetime.utcnow)

class ProjectTemplate(Base):
    __tablename__ = "project_templates"

    id = Column(String, primary_key=True, default=generate_uuid)
    user_id = Column(String, ForeignKey("users.id"), nullable=True) # Nullable for system templates
    name = Column(String, nullable=False)
    settings = Column(JSON, nullable=False)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

class ErrorLog(Base):
    __tablename__ = "error_logs"

    id = Column(Integer, primary_key=True, index=True)
    timestamp = Column(DateTime, default=datetime.datetime.utcnow)
    level = Column(String) # 'INFO', 'WARNING', 'ERROR', 'CRITICAL'
    message = Column(String)
    stack_trace = Column(Text, nullable=True)
    context = Column(JSON, nullable=True)
    user_id = Column(String, ForeignKey("users.id"), nullable=True)

    user = relationship("User", backref="error_logs")
