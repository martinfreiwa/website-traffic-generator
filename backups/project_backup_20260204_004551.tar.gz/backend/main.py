from dotenv import load_dotenv
import os

# Load environment variables from .env file
load_dotenv()

from fastapi import FastAPI, Depends, HTTPException, status, Header, Request, Response
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any
from pydantic import BaseModel
from jose import JWTError, jwt
from passlib.context import CryptContext
import models
from database import SessionLocal, engine, get_db
from enhanced_scheduler import scheduler
from enhanced_hit_emulator import ga_emu_engine
from sse_starlette.sse import EventSourceResponse
import json
import asyncio
from fastapi.security import APIKeyHeader
import secrets
import aiohttp
import re
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from fastapi import UploadFile, File
import shutil
from pathlib import Path

# ... existing code ...

# Create Tables
models.Base.metadata.create_all(bind=engine)

app = FastAPI(title="TrafficGen Pro SaaS API")

# Ensure upload directory exists
AVATAR_UPLOAD_DIR = os.path.join(os.getcwd(), "static", "uploads", "avatars")
os.makedirs(AVATAR_UPLOAD_DIR, exist_ok=True)


# Serve the frontend (will be in /app/static in Docker)
FRONTEND_PATH = os.path.join(os.getcwd(), "static")


@app.get("/health")
def health_check():
    return {"status": "ok"}


# --- Security & Auth Config ---
SECRET_KEY = os.getenv("JWT_SECRET_KEY")
if not SECRET_KEY:
    raise ValueError("JWT_SECRET_KEY environment variable must be set")
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = int(
    os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", "60")
)  # Default: 1 hour

# CORS - Configure based on environment
ALLOWED_ORIGINS = [
    "http://localhost:3000",
    "http://localhost:5173",
    "http://127.0.0.1:3000",
    "http://127.0.0.1:5173",
    "http://localhost:4173",
    "http://127.0.0.1:4173",
]
env_origins = os.getenv("ALLOWED_ORIGINS")
if env_origins:
    ALLOWED_ORIGINS.extend(env_origins.split(","))

app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="auth/token", auto_error=False)
api_key_header = APIKeyHeader(name="X-API-KEY", auto_error=False)


@app.on_event("startup")
async def startup_event():
    from setup_guide_key import setup_guide_api_key

    try:
        setup_guide_api_key()
    except Exception as e:
        print(f"Provisioning error: {e}")
    await scheduler.start()

    # Apply global traffic settings from DB on startup
    db = SessionLocal()
    try:
        settings_row = db.query(models.SystemSettings).first()
        if settings_row and settings_row.settings:
            # Default to True if not present
            traffic_enabled = settings_row.settings.get("traffic_enabled", True)
            scheduler.is_globally_paused = not traffic_enabled
            print(
                f"Global Traffic on Startup: {'ENABLED' if traffic_enabled else 'PAUSED'}"
            )
    except Exception as e:
        print(f"Failed to load global traffic settings: {e}")
    finally:
        db.close()


@app.on_event("shutdown")
async def shutdown_event():
    await scheduler.stop()


# --- Schemas ---


class UserCreate(BaseModel):
    email: str
    password: str
    name: str = "User"
    ref_code: Optional[str] = None  # Referral code from referrer


class UserResponse(BaseModel):
    id: str
    email: str
    name: Optional[str] = None
    role: str
    balance: float
    api_key: Optional[str] = None
    affiliate_code: Optional[str] = None
    phone: Optional[str] = None
    telegram: Optional[str] = None
    company: Optional[str] = None
    vat_id: Optional[str] = None
    address: Optional[str] = None
    city: Optional[str] = None
    zip: Optional[str] = None
    country: Optional[str] = None
    preferences: Optional[Dict[str, Any]] = None
    api_access_status: Optional[str] = "none"
    api_application_data: Optional[Dict[str, Any]] = None
    avatar_url: Optional[str] = None

    class Config:
        from_attributes = True


class UserUpdate(BaseModel):
    name: Optional[str] = None
    phone: Optional[str] = None
    telegram: Optional[str] = None
    company: Optional[str] = None
    vat_id: Optional[str] = None
    address: Optional[str] = None
    city: Optional[str] = None
    zip: Optional[str] = None
    country: Optional[str] = None
    preferences: Optional[Dict[str, Any]] = None


class ApiApplication(BaseModel):
    usage_description: str
    target_websites: str


class PasswordChange(BaseModel):
    old_password: str
    new_password: str


class ProxyCreate(BaseModel):
    url: str
    country: Optional[str] = None
    state: Optional[str] = None
    city: Optional[str] = None


class ProxyResponse(BaseModel):
    id: int
    url: str
    country: Optional[str] = None
    is_active: bool

    class Config:
        from_attributes = True


class Token(BaseModel):
    access_token: str
    token_type: str


class ProjectCreate(BaseModel):
    name: str
    plan_type: str = "Custom"
    settings: Dict[str, Any]  # THE JSONB PAYLOAD
    daily_limit: int = 0
    total_target: int = 0


class ProjectResponse(BaseModel):
    id: str
    name: str
    status: str
    settings: Dict[str, Any]
    daily_limit: int
    total_target: int
    hits_today: int = 0
    total_hits: int = 0
    created_at: datetime

    class Config:
        from_attributes = True


class TransactionResponse(BaseModel):
    id: str
    type: str
    amount: float
    description: Optional[str]
    status: str
    created_at: datetime

    class Config:
        from_attributes = True


class AffiliateEarningResponse(BaseModel):
    id: str
    amount: float
    status: str
    created_at: datetime
    referee_email: Optional[str] = None  # Added via join

    class Config:
        from_attributes = True


class QuoteResponse(BaseModel):
    estimated_visits: int
    rate: float


class DepositRequest(BaseModel):
    user_email: str
    amount: float
    description: Optional[str] = "Manual Funding"


class TicketCreate(BaseModel):
    subject: str
    priority: str = "low"
    project_id: Optional[str] = None
    messages: List[Dict[str, Any]] = []


class TicketReply(BaseModel):
    text: str
    sender: str  # 'user', 'admin', or 'guest'
    attachments: Optional[List[str]] = []


class TicketStatusUpdate(BaseModel):
    status: str


class TicketPriorityUpdate(BaseModel):
    priority: str


class TicketResponse(BaseModel):
    id: str
    subject: str
    status: str
    priority: str
    project_id: Optional[str] = None
    messages: List[Dict[str, Any]]
    created_at: datetime

    class Config:
        from_attributes = True


class NotificationResponse(BaseModel):
    id: str
    title: str
    message: str
    type: str
    is_read: bool
    created_at: datetime

    class Config:
        from_attributes = True


class SystemSettingsUpdate(BaseModel):
    settings: Dict[str, Any]


class TrafficStart(BaseModel):
    targets: List[Dict[str, Any]]
    visitors_per_min: int
    duration_mins: int
    mode: str = "direct_hit"
    returning_visitor_pct: Optional[int] = 0
    bounce_rate_pct: Optional[int] = 0
    referrer: Optional[str] = ""
    traffic_source_preset: Optional[str] = "direct"
    utm_tags: Optional[Dict[str, Any]] = None
    device_distribution: Optional[Dict[str, Any]] = None
    target_country: Optional[str] = None
    target_state: Optional[str] = None
    target_city: Optional[str] = None
    is_dry_run: bool = False
    total_visitor_count: Optional[int] = None


class AdminProjectCreate(ProjectCreate):
    user_id: str


class QuickStartRequest(BaseModel):
    email: str
    url: str
    visitors: int


class ErrorLogResponse(BaseModel):
    id: int
    timestamp: datetime
    level: str
    message: str
    stack_trace: Optional[str] = None
    context: Optional[Dict[str, Any]] = None
    user_id: Optional[str] = None

    class Config:
        from_attributes = True


# --- Helpers ---


def verify_password(plain_password, hashed_password):
    return pwd_context.verify(plain_password, hashed_password)


def get_password_hash(password):
    return pwd_context.hash(password)


def create_access_token(data: dict, expires_delta: Optional[timedelta] = None):
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=15)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt


async def get_current_user(
    token: Optional[str] = Depends(oauth2_scheme),
    api_key: Optional[str] = Depends(api_key_header),
    db: Session = Depends(get_db),
):
    """Hybrid authentication: Supports both JWT and API Keys"""
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )

    if api_key:
        user = db.query(models.User).filter(models.User.api_key == api_key).first()
        if user:
            return user

    if token:
        try:
            payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
            email: str = payload.get("sub")
            if email:
                user = db.query(models.User).filter(models.User.email == email).first()
                if user:
                    return user
        except JWTError:
            pass

    raise credentials_exception


# get_current_user_optional is now an alias for get_current_user as both support hybrid auth
get_current_user_optional = get_current_user


# --- Endpoints ---


@app.post("/auth/register", response_model=UserResponse)
def register(user: UserCreate, db: Session = Depends(get_db)):
    db_user = db.query(models.User).filter(models.User.email == user.email).first()
    if db_user:
        raise HTTPException(status_code=400, detail="Email already registered")

    # Affiliate mapping
    referred_by_id = None
    if user.ref_code:
        referrer = (
            db.query(models.User)
            .filter(models.User.affiliate_code == user.ref_code)
            .first()
        )
        if referrer:
            referred_by_id = referrer.id

    hashed_password = get_password_hash(user.password)
    new_user = models.User(
        email=user.email,
        password_hash=hashed_password,
        referred_by=referred_by_id,
        # Generate basic affiliate code
        affiliate_code=f"REF-{user.email[:3].upper()}-{secrets.token_hex(3).upper()}",
    )
    db.add(new_user)
    db.commit()
    db.refresh(new_user)
    return new_user


@app.post("/auth/quick-start", response_model=Dict[str, Any])
def quick_start(request: QuickStartRequest, db: Session = Depends(get_db)):
    # 1. Check or Create User
    user = db.query(models.User).filter(models.User.email == request.email).first()
    generated_password = None
    is_new_user = False

    if not user:
        # Generate random secure password
        alphabet = (
            "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*"
        )
        generated_password = "".join(secrets.choice(alphabet) for i in range(12))
        hashed_password = get_password_hash(generated_password)

        user = models.User(
            email=request.email,
            password_hash=hashed_password,
            affiliate_code=f"REF-{request.email[:3].upper()}-{secrets.token_hex(3).upper()}",
            balance=0.0,
        )
        db.add(user)
        db.commit()
        db.refresh(user)
        is_new_user = True

    # 2. Create "Free Traffic" Project
    # visitors is visitors per day for 1 day request.
    # We'll set daily_limit to the requested amount and total_target to the same (1 day run)

    project_settings = {
        "targets": [{"url": request.url, "weight": 100}],
        "visitors_per_min": max(1, int(request.visitors / 1440)),  # Averaged over 24h
        "duration_mins": 1440,
        "mode": "smart_distribution",
        "device_distribution": {"desktop": 70, "mobile": 30},
        "target_country": "US",  # Default to US for free tier
    }

    db_project = models.Project(
        user_id=user.id,
        name=f"Free Traffic - {request.url.replace('https://', '').replace('http://', '')[:20]}",
        plan_type="Free Trial",
        daily_limit=request.visitors,
        total_target=request.visitors,
        status="active",
        settings=project_settings,
        expires_at=datetime.utcnow() + timedelta(days=1),
    )
    db.add(db_project)
    db.commit()

    # 3. Generate Login Token
    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": user.email}, expires_delta=access_token_expires
    )

    return {
        "access_token": access_token,
        "token_type": "bearer",
        "user_email": user.email,
        "is_new_user": is_new_user,
        "generated_password": generated_password,  # Frontend should show this to the user!
        "project_id": db_project.id,
    }


@app.post("/auth/token", response_model=Token)
def login_for_access_token(
    form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)
):
    user = db.query(models.User).filter(models.User.email == form_data.username).first()
    if not user or not verify_password(form_data.password, user.password_hash):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": user.email}, expires_delta=access_token_expires
    )
    return {"access_token": access_token, "token_type": "bearer"}


@app.get("/users/me", response_model=UserResponse)
def read_users_me(current_user: models.User = Depends(get_current_user_optional)):
    return current_user


@app.put("/users/me", response_model=UserResponse)
def update_user_me(
    user_update: UserUpdate,
    current_user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Update current user profile"""
    update_data = user_update.dict(exclude_unset=True)
    for key, value in update_data.items():
        setattr(current_user, key, value)

    if "preferences" in update_data:
        from sqlalchemy.orm.attributes import flag_modified

        flag_modified(current_user, "preferences")

    db.commit()
    db.refresh(current_user)
    return current_user


@app.post("/users/me/avatar")
async def upload_avatar(
    file: UploadFile = File(...),
    current_user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Upload user profile picture"""
    # 1. Validate file extension
    file_ext = Path(file.filename).suffix.lower()
    if file_ext not in [".jpg", ".jpeg", ".png", ".webp"]:
        raise HTTPException(
            status_code=400, detail="Invalid file type. Only JPG, PNG, WEBP allowed."
        )

    # 2. Create unique filename
    filename = f"{current_user.id}_{secrets.token_hex(4)}{file_ext}"
    file_path = os.path.join(AVATAR_UPLOAD_DIR, filename)

    # 3. Save file
    with open(file_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    # 4. Update User record
    # We store the relative path for the frontend to access via /static/uploads/avatars/...
    # Or /uploads/avatars/... depending on static mount
    avatar_url = f"/uploads/avatars/{filename}"
    current_user.avatar_url = avatar_url
    db.commit()

    return {"avatar_url": avatar_url}


@app.post("/auth/change-password")
def change_password(
    data: PasswordChange,
    current_user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Change user password"""
    if not verify_password(data.old_password, current_user.password_hash):
        raise HTTPException(status_code=400, detail="Incorrect old password")

    current_user.password_hash = get_password_hash(data.new_password)
    db.commit()
    return {"status": "success", "message": "Password changed successfully"}


@app.post("/auth/api-key")
def generate_api_key(
    current_user: models.User = Depends(get_current_user), db: Session = Depends(get_db)
):
    """Generate a high-entropy API key - restricted to approved users"""
    if current_user.api_access_status != "approved" and current_user.role != "admin":
        raise HTTPException(
            status_code=403,
            detail="API access not approved. Please apply in your profile.",
        )

    new_key = f"tgp_{secrets.token_urlsafe(32)}"
    current_user.api_key = new_key
    db.commit()
    return {"api_key": new_key}


# --- API Access Application Endpoints ---


@app.post("/users/me/apply-api")
def apply_for_api_access(
    application: ApiApplication,
    current_user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Submit an application for API access"""
    if current_user.api_access_status == "pending":
        raise HTTPException(status_code=400, detail="Application already pending")

    current_user.api_access_status = "pending"
    current_user.api_application_data = {
        "usage_description": application.usage_description,
        "target_websites": application.target_websites,
        "applied_at": datetime.utcnow().isoformat(),
    }
    db.commit()
    return {
        "status": "success",
        "message": "Application submitted. Usually takes < 24h.",
    }


@app.get("/admin/api-applications")
def get_api_applications(
    status: Optional[str] = "pending",
    current_user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Admin view: list API applications"""
    if current_user.role != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")

    query = db.query(models.User).filter(models.User.api_access_status != "none")
    if status:
        query = query.filter(models.User.api_access_status == status)

    return query.all()


@app.post("/admin/api-applications/{user_id}/approve")
def approve_api_access(
    user_id: str,
    current_user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Admin: Approve API access"""
    if current_user.role != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")

    target_user = db.query(models.User).filter(models.User.id == user_id).first()
    if not target_user:
        raise HTTPException(status_code=404, detail="User not found")

    target_user.api_access_status = "approved"
    # Auto-generate key on approval
    target_user.api_key = f"tgp_{secrets.token_urlsafe(32)}"
    db.commit()

    # Create notification for user
    notif = models.Notification(
        user_id=target_user.id,
        title="API Access Approved",
        message="Your API access request has been approved. You can now view your key and documentation in your profile.",
        type="success",
    )
    db.add(notif)
    db.commit()

    return {"status": "success", "message": "API access approved"}


@app.post("/admin/api-applications/{user_id}/reject")
def reject_api_access(
    user_id: str,
    current_user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Admin: Reject API access"""
    if current_user.role != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")

    target_user = db.query(models.User).filter(models.User.id == user_id).first()
    if not target_user:
        raise HTTPException(status_code=404, detail="User not found")

    target_user.api_access_status = "rejected"
    db.commit()

    # Create notification for user
    notif = models.Notification(
        user_id=target_user.id,
        title="API Access Request Updated",
        message="Unfortunately, your API access request was not approved at this time.",
        type="warning",
    )
    db.add(notif)
    db.commit()

    return {"status": "success", "message": "API access rejected"}


@app.delete("/auth/api-key")
def revoke_api_key(
    current_user: models.User = Depends(get_current_user), db: Session = Depends(get_db)
):
    current_user.api_key = None
    db.commit()
    return {"status": "revoked"}


@app.post("/admin/promote")
def promote_user(
    target_email: str,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    """Promotion logic: First user can become admin, thereafter only admins can promote"""
    admin_count = db.query(models.User).filter(models.User.role == "admin").count()
    user = db.query(models.User).filter(models.User.email == target_email).first()

    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    if admin_count == 0:
        # First one is free - bootstrap mode
        user.role = "admin"
        db.commit()
        return {"status": "promoted (bootstrap)", "email": target_email}

    # After bootstrap, only admins can promote
    if current_user.role != "admin":
        raise HTTPException(
            status_code=403, detail="Admin access required to promote users"
        )

    user.role = "admin"
    db.commit()
    return {"status": "promoted", "email": target_email}


@app.get("/transactions", response_model=List[TransactionResponse])
def get_transactions(
    db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)
):
    return (
        db.query(models.Transaction)
        .filter(models.Transaction.user_id == current_user.id)
        .order_by(models.Transaction.created_at.desc())
        .all()
    )


@app.get("/affiliate/earnings", response_model=List[AffiliateEarningResponse])
def get_affiliate_earnings(
    db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)
):
    # Join with User to get referee email
    earnings = (
        db.query(models.AffiliateEarnings, models.User.email)
        .join(models.User, models.AffiliateEarnings.referee_id == models.User.id)
        .filter(models.AffiliateEarnings.referrer_id == current_user.id)
        .all()
    )

    result = []
    for earning, email in earnings:
        data = AffiliateEarningResponse.from_orm(earning)
        data.referee_email = email
        result.append(data)
    return result


# --- Project Management (SaaS Style) ---


@app.post("/projects", response_model=ProjectResponse)
def create_project(
    project: ProjectCreate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    # 1. Billing Check? (Skipped for Foundation Phase, to be added in Phase 2)
    # if current_user.balance < cost: ...

    db_project = models.Project(
        user_id=current_user.id,
        name=project.name,
        plan_type=project.plan_type,
        daily_limit=project.daily_limit,
        total_target=project.total_target,
        hits_today=0,
        total_hits=0,
        settings=project.settings,  # Just dump the JSON!
    )
    db.add(db_project)
    db.commit()
    db.refresh(db_project)
    return db_project


@app.get("/projects", response_model=List[ProjectResponse])
def get_projects(
    db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)
):
    if current_user.role == "admin":
        return db.query(models.Project).all()
    return (
        db.query(models.Project).filter(models.Project.user_id == current_user.id).all()
    )


@app.get("/projects/{project_id}", response_model=ProjectResponse)
def get_project_details(
    project_id: str,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    project = db.query(models.Project).filter(models.Project.id == project_id).first()
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")

    if current_user.role != "admin" and project.user_id != current_user.id:
        raise HTTPException(
            status_code=403, detail="Not authorized to access this project"
        )
    return project


class ProjectUpdate(BaseModel):
    name: Optional[str] = None
    plan_type: Optional[str] = None
    settings: Optional[Dict[str, Any]] = None
    daily_limit: Optional[int] = None
    total_target: Optional[int] = None


@app.put("/projects/{project_id}", response_model=ProjectResponse)
def update_project(
    project_id: str,
    project_update: ProjectUpdate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    # Check permissions
    db_project = (
        db.query(models.Project).filter(models.Project.id == project_id).first()
    )
    if not db_project:
        raise HTTPException(status_code=404, detail="Project not found")

    if current_user.role != "admin" and db_project.user_id != current_user.id:
        raise HTTPException(
            status_code=403, detail="Not authorized to update this project"
        )

    # Update fields if provided
    if project_update.name is not None:
        db_project.name = project_update.name
    if project_update.plan_type is not None:
        db_project.plan_type = project_update.plan_type
    if project_update.settings is not None:
        db_project.settings = project_update.settings
    if project_update.daily_limit is not None:
        db_project.daily_limit = project_update.daily_limit
    if project_update.total_target is not None:
        db_project.total_target = project_update.total_target

    db.commit()
    db.refresh(db_project)
    return db_project


# --- Proxy Management ---


@app.post("/proxies", response_model=ProxyResponse)
def create_proxy(
    proxy: ProxyCreate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    if current_user.role != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")
    db_proxy = models.Proxy(**proxy.dict())
    db.add(db_proxy)
    db.commit()
    db.refresh(db_proxy)
    return db_proxy


@app.get("/proxies", response_model=List[ProxyResponse])
def get_proxies(db: Session = Depends(get_db)):
    return db.query(models.Proxy).all()


@app.post("/projects/{project_id}/stop", response_model=ProjectResponse)
def stop_project(
    project_id: str,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    project = (
        db.query(models.Project)
        .filter(
            models.Project.id == project_id, models.Project.user_id == current_user.id
        )
        .first()
    )
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    project.status = "stopped"
    db.commit()
    return project


@app.post("/projects/{project_id}/start", response_model=ProjectResponse)
def start_project(
    project_id: str,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    project = (
        db.query(models.Project)
        .filter(
            models.Project.id == project_id, models.Project.user_id == current_user.id
        )
        .first()
    )
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    project.status = "active"
    db.commit()
    return project


# --- Billing Logic (Pricing & Webhooks) ---


@app.get("/billing/quote", response_model=QuoteResponse)
def get_quote(amount: float):
    # Dynamic Rate Calculation based on Volume Tiers from BuyCredits.tsx
    # | Tier      | Rate     |
    # | < 129     | 0.00058  |
    # | < 399     | 0.00043  |
    # | < 999     | 0.00040  |
    # | < 1249    | 0.00033  |
    # | < 2999    | 0.00025  |
    # | >= 2999   | 0.00020  |

    if amount >= 2999:
        rate = 0.000199933  # Agency Scale
    elif amount >= 1249:
        rate = 0.0002498  # Agency Pro
    elif amount >= 999:
        rate = 0.000333  # Enterprise
    elif amount >= 399:
        rate = 0.000399  # Business
    elif amount >= 129:
        rate = 0.00043  # Growth
    else:
        rate = 0.00058  # Starter

    estimated_visits = int(amount / rate)
    return {"estimated_visits": estimated_visits, "rate": rate}


import hmac
import hashlib


@app.post("/webhooks/deposit")
def simulate_deposit(
    data: DepositRequest,
    db: Session = Depends(get_db),
    x_webhook_signature: str = Header(None, alias="X-Webhook-Signature"),
):
    # 1. Verify webhook signature if WEBHOOK_SECRET is configured
    webhook_secret = os.getenv("WEBHOOK_SECRET")
    if webhook_secret:
        if not x_webhook_signature:
            raise HTTPException(status_code=401, detail="Missing webhook signature")

        # Compute expected signature
        payload = json.dumps(data.dict(), sort_keys=True)
        expected_sig = hmac.new(
            webhook_secret.encode(), payload.encode(), hashlib.sha256
        ).hexdigest()

        if not hmac.compare_digest(x_webhook_signature, expected_sig):
            raise HTTPException(status_code=401, detail="Invalid webhook signature")

    # 2. Find User
    user = db.query(models.User).filter(models.User.email == data.user_email).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    # 2. Add Balance
    user.balance += data.amount

    # 3. Create Transaction
    trx = models.Transaction(
        user_id=user.id, type="credit", amount=data.amount, description=data.description
    )
    db.add(trx)
    db.commit()
    db.refresh(trx)

    # 4. Affiliate Commission (20% Lifetime)
    if user.referred_by:
        referrer = (
            db.query(models.User).filter(models.User.id == user.referred_by).first()
        )
        if referrer:
            commission = data.amount * 0.20

            # Create Earning record
            earning = models.AffiliateEarnings(
                referrer_id=referrer.id,
                referee_id=user.id,
                transaction_id=trx.id,
                amount=commission,
                status="pending",
            )
            db.add(earning)

            # Update referrer balance (SaaS often adds to balance or separate wallet, here we add to balance)
            referrer.balance += commission

            # Add transaction for referrer
            ref_trx = models.Transaction(
                user_id=referrer.id,
                type="bonus",
                amount=commission,
                description=f"Affiliate Commission from {user.email}",
            )
            db.add(ref_trx)

    db.commit()
    return {"status": "success", "new_balance": user.balance}


@app.post("/start")
async def start_traffic_adhoc(
    data: TrafficStart,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    """Global start endpoint for ad-hoc simulations from the UI"""
    # Create a transient project name for ad-hoc runs
    p_name = f"Ad-hoc Run {datetime.now().strftime('%Y-%m-%d %H:%M')}"

    # Calculate targets for the scheduler
    # VPM * 1440 mins = equivalent daily limit to maintain that speed
    calculated_daily_limit = data.visitors_per_min * 1440
    # Total visitors for this specific run
    calculated_total_target = data.visitors_per_min * data.duration_mins

    expires_at = datetime.utcnow() + timedelta(minutes=data.duration_mins)

    # Save as a project first so the scheduler can pick it up
    db_project = models.Project(
        user_id=current_user.id,
        name=p_name,
        plan_type="Ad-hoc",
        status="active",
        daily_limit=calculated_daily_limit,
        total_target=calculated_total_target,
        expires_at=expires_at,
        settings=data.dict(),
    )
    db.add(db_project)
    db.commit()
    db.refresh(db_project)

    # Trigger scheduler check immediately
    await scheduler.check_and_run()

    return {"status": "started", "project_id": db_project.id}


@app.post("/stop")
async def stop_traffic_adhoc(
    current_user: models.User = Depends(get_current_user), db: Session = Depends(get_db)
):
    """Global stop endpoint - stops all active projects for the user"""
    active_projects = (
        db.query(models.Project)
        .filter(
            models.Project.user_id == current_user.id, models.Project.status == "active"
        )
        .all()
    )
    for p in active_projects:
        p.status = "stopped"
    db.commit()

    # Force stop the engines immediately
    # We can't stop the scheduler logic entirely or it won't restart, but we can tell the emulator to stop.
    ga_emu_engine.stop()

    return {"status": "stopped", "count": len(active_projects)}


@app.get("/stats")
def get_global_stats(current_user: models.User = Depends(get_current_user)):
    # Aggregate stats across all projects for the dashboard overview
    total_success = sum(s.get("success", 0) for s in ga_emu_engine.stats.values())
    total_failure = sum(s.get("failure", 0) for s in ga_emu_engine.stats.values())

    # We'll map these to visit_stats/hit_stats as expected by the frontend
    # For now, we'll just put the totals in a special key or mock the per-url view
    # if the frontend logic expects per-url, but aggregated is better for the main dashboard.

    return {
        "visit_stats": {
            "Total": {
                "success": total_success,
                "failure": total_failure,
                "total": total_success + total_failure,
            }
        },
        "hit_stats": {
            "Total": {"success": 0, "failure": 0, "total": 0}
        },  # Legacy compatibility
        "is_running": scheduler.is_running,
        "recent_events": [],  # Handled by SSE now
    }


@app.get("/projects/{project_id}/analytics")
def get_project_analytics(
    project_id: str,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    """Get detailed analytics for a specific project"""
    project = db.query(models.Project).filter(models.Project.id == project_id).first()
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    if project.user_id != current_user.id and current_user.role != "admin":
        raise HTTPException(status_code=403, detail="Access denied")

    # Get recent traffic logs with enhanced data
    logs = (
        db.query(models.TrafficLog)
        .filter(models.TrafficLog.project_id == project_id)
        .order_by(models.TrafficLog.timestamp.desc())
        .limit(100)
        .all()
    )

    # Get hourly stats
    stats = (
        db.query(models.ProjectStats)
        .filter(models.ProjectStats.project_id == project_id)
        .order_by(models.ProjectStats.hour.desc())
        .limit(24)
        .all()
    )

    # Calculate aggregate metrics
    total_visitors = sum(s.total_visitors for s in stats)
    bounce_count = sum(s.bounce_count for s in stats)
    bounce_rate = (bounce_count / total_visitors * 100) if total_visitors > 0 else 0
    avg_session_duration = (
        sum(s.avg_session_duration for s in stats) / len(stats) if stats else 0
    )

    return {
        "project_id": project_id,
        "total_visitors": total_visitors,
        "bounce_rate": round(bounce_rate, 2),
        "avg_session_duration": round(avg_session_duration, 2),
        "device_breakdown": {
            "desktop": sum(s.desktop_visitors for s in stats),
            "mobile": sum(s.mobile_visitors for s in stats),
            "tablet": sum(s.tablet_visitors for s in stats),
        },
        "source_breakdown": {
            "organic": sum(s.organic_visitors for s in stats),
            "social": sum(s.social_visitors for s in stats),
            "direct": sum(s.direct_visitors for s in stats),
            "referral": sum(s.referral_visitors for s in stats),
        },
        "hourly_stats": [
            {
                "hour": s.hour.isoformat(),
                "visitors": s.total_visitors,
                "bounce_rate": round(s.bounce_count / s.total_visitors * 100, 2)
                if s.total_visitors > 0
                else 0,
            }
            for s in reversed(stats)
        ],
        "recent_sessions": [
            {
                "timestamp": log.timestamp.isoformat(),
                "url": log.url,
                "device_type": log.device_type,
                "traffic_source": log.traffic_source,
                "bounced": log.bounced,
                "session_duration": log.session_duration,
                "pages_viewed": log.pages_viewed,
            }
            for log in logs
        ],
    }


@app.get("/admin/live-pulse")
async def live_pulse(db: Session = Depends(get_db)):
    """SSE endpoint for real-time traffic monitoring"""

    async def event_generator():
        last_id = 0
        while True:
            # Fetch logs newer than what we've already sent
            new_logs = (
                db.query(models.TrafficLog)
                .filter(models.TrafficLog.id > last_id)
                .order_by(models.TrafficLog.id.desc())
                .limit(10)
                .all()
            )
            if new_logs:
                last_id = new_logs[0].id
                logs_data = []
                for log in new_logs:
                    logs_data.append(
                        {
                            "id": log.id,
                            "project_id": log.project_id,
                            "timestamp": log.timestamp.isoformat(),
                            "url": log.url,
                            "status": log.status,
                            "type": log.event_type,
                            "proxy": log.proxy,
                        }
                    )
                yield {"data": json.dumps(logs_data)}
            await asyncio.sleep(2)  # Pulse every 2 seconds

    return EventSourceResponse(event_generator())


@app.get("/admin/stats")
def get_admin_stats(
    db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)
):
    if current_user.role != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")

    total_revenue = (
        db.query(models.Transaction)
        .filter(models.Transaction.type == "credit")
        .with_entities(models.Transaction.amount)
        .all()
    )
    revenue_sum = sum([r[0] for r in total_revenue])

    active_users = db.query(models.User).count()
    active_projects = (
        db.query(models.Project).filter(models.Project.status == "active").count()
    )
    total_hits = db.query(models.Project).with_entities(models.Project.total_hits).all()
    hits_sum = sum([h[0] for h in total_hits])

    return {
        "total_revenue": revenue_sum,
        "active_users": active_users,
        "active_projects": active_projects,
        "total_hits_sent": hits_sum,
        "system_status": "operational",
    }


@app.get("/admin/traffic-stats")
def get_admin_traffic_stats(
    range: str = "24h",
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    """Aggregated traffic metrics for admin dashboard across different time ranges"""
    if current_user.role != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")

    now = datetime.utcnow()

    if range == "30m":
        start_time = now - timedelta(minutes=30)
        interval = "1m"  # Approx 30 data points
        group_by_fmt = "%Y-%m-%d %H:%M"
    elif range == "24h":
        start_time = now - timedelta(hours=24)
        interval = "1h"  # 24 data points
        group_by_fmt = "%Y-%m-%d %H:00"
    elif range == "7d":
        start_time = now - timedelta(days=7)
        interval = "1d"  # 7 data points
        group_by_fmt = "%Y-%m-%d"
    elif range == "30d":
        start_time = now - timedelta(days=30)
        interval = "1d"  # 30 data points
        group_by_fmt = "%Y-%m-%d"
    else:
        start_time = now - timedelta(hours=24)
        group_by_fmt = "%Y-%m-%d %H:00"

    # Query traffic logs
    logs = (
        db.query(models.TrafficLog)
        .filter(models.TrafficLog.timestamp >= start_time)
        .filter(models.TrafficLog.event_type == "session_start")
        .all()
    )

    # Aggregate by time bucket
    buckets = {}

    # Initialize buckets to ensure all time slots have data (even if 0)
    curr = start_time
    while curr <= now:
        fmt_key = curr.strftime(group_by_fmt)
        buckets[fmt_key] = 0
        if range == "30m":
            curr += timedelta(minutes=1)
        elif range == "24h":
            curr += timedelta(hours=1)
        else:
            curr += timedelta(days=1)

    for log in logs:
        fmt_key = log.timestamp.strftime(group_by_fmt)
        if fmt_key in buckets:
            buckets[fmt_key] += 1

    # Format for frontend
    result = []
    for key in sorted(buckets.keys()):
        result.append({"timestamp": key, "visitors": buckets[key]})

    return result

    return result


@app.get("/admin/analytics/realtime")
def get_realtime_analytics(
    range: str = "24h",
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    if current_user.role != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")

    from sqlalchemy import func, text

    now = datetime.utcnow()

    # 1. Active Visitors (Last 5 mins)
    five_min_ago = now - timedelta(minutes=5)
    active_visitors = (
        db.query(models.TrafficLog)
        .filter(
            models.TrafficLog.timestamp >= five_min_ago,
            models.TrafficLog.event_type == "session_start",
        )
        .count()
    )

    # 2. Total Visitors Today (Since midnight)
    midnight = now.replace(hour=0, minute=0, second=0, microsecond=0)
    total_today = (
        db.query(models.Project)
        .with_entities(func.sum(models.Project.hits_today))
        .scalar()
        or 0
    )

    # 3. Active Campaigns
    active_campaigns = (
        db.query(models.Project).filter(models.Project.status == "active").count()
    )
    total_projects = db.query(models.Project).count()

    # 4. Global Stats (Bounce Rate, Avg Duration) - Last 24h
    day_ago = now - timedelta(hours=24)
    stats_24h = (
        db.query(models.ProjectStats).filter(models.ProjectStats.hour >= day_ago).all()
    )

    total_visits_24h = sum(s.total_visitors for s in stats_24h)
    total_bounces_24h = sum(s.bounce_count for s in stats_24h)

    bounce_rate = 0
    if total_visits_24h > 0:
        bounce_rate = round((total_bounces_24h / total_visits_24h) * 100, 1)

    # Weighted Average Duration
    avg_duration = 0
    if total_visits_24h > 0:
        total_duration_seconds = sum(
            s.avg_session_duration * s.total_visitors for s in stats_24h
        )
        avg_duration = int(total_duration_seconds / total_visits_24h)

    # 5. Traffic History (Chart)
    # Aggregate by hour
    history_buckets = {}
    curr = day_ago.replace(minute=0, second=0, microsecond=0)
    while curr <= now:
        key = curr.strftime("%H:00")
        history_buckets[key] = {"time": key, "visitors": 0, "pageViews": 0}
        curr += timedelta(hours=1)

    for s in stats_24h:
        key = s.hour.strftime("%H:00")
        if key in history_buckets:
            history_buckets[key]["visitors"] += s.total_visitors
            # Rough estimate: successful_hits ~ pageviews (or close enough)
            history_buckets[key]["pageViews"] += s.successful_hits

    history = list(history_buckets.values())

    # 6. Device Breakdown
    desktop = sum(s.desktop_visitors for s in stats_24h)
    mobile = sum(s.mobile_visitors for s in stats_24h)
    tablet = sum(s.tablet_visitors for s in stats_24h)
    total_devices = desktop + mobile + tablet

    device_breakdown = []
    if total_devices > 0:
        device_breakdown = [
            {"name": "Desktop", "value": round((desktop / total_devices) * 100, 1)},
            {"name": "Mobile", "value": round((mobile / total_devices) * 100, 1)},
            {"name": "Tablet", "value": round((tablet / total_devices) * 100, 1)},
        ]
    else:
        # Default empty if no data
        device_breakdown = [
            {"name": "Desktop", "value": 0},
            {"name": "Mobile", "value": 0},
            {"name": "Tablet", "value": 0},
        ]

    # 7. Geo Distribution (Top 5)
    # Query TrafficLogs directly for accuracy on Country
    top_countries = (
        db.query(
            models.TrafficLog.country, func.count(models.TrafficLog.id).label("count")
        )
        .filter(models.TrafficLog.timestamp >= day_ago)
        .group_by(models.TrafficLog.country)
        .order_by(text("count DESC"))
        .limit(5)
        .all()
    )

    geo_dist = []
    country_flags = {
        "United States": "🇺🇸",
        "Germany": "🇩🇪",
        "United Kingdom": "🇬🇧",
        "France": "🇫🇷",
        "Canada": "🇨🇦",
        "Italy": "🇮🇹",
        "Spain": "🇪🇸",
        "Netherlands": "🇳🇱",
        "Brazil": "🇧🇷",
        "India": "🇮🇳",
        "Japan": "🇯🇵",
    }

    for country, count in top_countries:
        c_name = country or "Unknown"
        geo_dist.append(
            {
                "country": c_name,
                "visitors": count,
                "flag": country_flags.get(c_name, "🌍"),
            }
        )

    # 8. Campaign Statuses
    active_projs = (
        db.query(models.Project).filter(models.Project.status == "active").all()
    )
    campaign_statuses = []

    for p in active_projs:
        # Check velocity (hits last hour)
        hour_ago = now - timedelta(hours=1)
        hits_last_hour = (
            db.query(models.TrafficLog)
            .filter(
                models.TrafficLog.project_id == p.id,
                models.TrafficLog.timestamp >= hour_ago,
            )
            .count()
        )

        completion = 0
        if p.total_target > 0:
            completion = round((p.total_hits / p.total_target) * 100, 1)

        campaign_statuses.append(
            {
                "projectId": p.id,
                "projectName": p.name,
                "status": "active",
                "visitorsLastHour": hits_last_hour,
                "visitorsToday": p.hits_today,
                "completionRate": completion,
            }
        )

    return {
        "stats": {
            "activeVisitors": active_visitors,
            "totalVisitorsToday": total_today,
            "activeCampaigns": active_campaigns,
            "totalProjects": total_projects,
            "avgSessionDuration": avg_duration,
            "bounceRate": bounce_rate,
        },
        "history": history,
        "devices": device_breakdown,
        "geo": geo_dist,
        "campaigns": campaign_statuses,
    }


@app.get("/admin/simulator/status")
def get_simulator_status(current_user: models.User = Depends(get_current_user)):
    """Internal status of the hit engine for admin UI"""
    if current_user.role != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")

    return {
        "logs": ga_emu_engine.engine_logs,
        "stats": ga_emu_engine.stats,
        "is_running": ga_emu_engine.is_running,
    }


@app.get("/admin/traffic-sources")
def get_traffic_source_options(current_user: models.User = Depends(get_current_user)):
    """Get all available traffic source options"""
    if current_user.role != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")

    from enhanced_hit_emulator import (
        SOCIAL_REFERRERS,
        ORGANIC_REFERRERS,
        CHATBOT_REFERRERS,
        MESSENGER_REFERRERS,
        NEWS_REFERRERS,
    )

    return {
        "social": list(SOCIAL_REFERRERS.keys()),
        "organic": list(ORGANIC_REFERRERS.keys()),
        "chatbots": list(CHATBOT_REFERRERS.keys()),
        "messengers": list(MESSENGER_REFERRERS.keys()),
        "news": list(NEWS_REFERRERS.keys()),
    }


@app.get("/admin/browser-options")
def get_browser_options(current_user: models.User = Depends(get_current_user)):
    """Get available browser options for device fingerprinting"""
    if current_user.role != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")

    from enhanced_hit_emulator import BROWSER_WEIGHTS

    return {
        "browsers": list(BROWSER_WEIGHTS.keys()),
        "weights": BROWSER_WEIGHTS,
    }


@app.get("/admin/users", response_model=List[UserResponse])
def get_all_users(
    db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)
):
    if current_user.role != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")
    return db.query(models.User).all()


@app.get("/admin/transactions", response_model=List[TransactionResponse])
def get_all_transactions(
    db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)
):
    if current_user.role != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")
    return db.query(models.Transaction).all()


@app.post("/admin/projects", response_model=ProjectResponse)
def admin_create_project(
    project: AdminProjectCreate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    if current_user.role != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")

    target_user = (
        db.query(models.User).filter(models.User.id == project.user_id).first()
    )
    if not target_user:
        raise HTTPException(status_code=404, detail="Target user not found")

    db_project = models.Project(
        user_id=project.user_id,  # Assign to specific user
        name=project.name,
        plan_type=project.plan_type,
        daily_limit=project.daily_limit,
        total_target=project.total_target,
        hits_today=0,
        total_hits=0,
        settings=project.settings,
    )
    db.add(db_project)
    db.commit()
    db.refresh(db_project)
    return db_project


@app.get("/admin/errors", response_model=List[ErrorLogResponse])
def get_error_logs(
    limit: int = 100,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    if current_user.role != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")
    return (
        db.query(models.ErrorLog)
        .order_by(models.ErrorLog.timestamp.desc())
        .limit(limit)
        .all()
    )


@app.post("/admin/errors/log")
def create_client_error_log(
    data: Dict[str, Any],
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    # Allow clients to report errors (e.g. frontend crashes)
    new_log = models.ErrorLog(
        level=data.get("level", "ERROR"),
        message=data.get("message", "Unknown client error"),
        stack_trace=data.get("stack_trace"),
        context=data.get("context"),
        user_id=current_user.id,
    )
    db.add(new_log)
    db.commit()
    return {"status": "logged"}


# --- Project Templates ---


class ProjectTemplateCreate(BaseModel):
    name: str
    settings: Dict[str, Any]


class ProjectTemplateResponse(BaseModel):
    id: str
    name: str
    settings: Dict[str, Any]
    created_at: datetime

    class Config:
        from_attributes = True


@app.post("/templates", response_model=ProjectTemplateResponse)
def create_template(
    template: ProjectTemplateCreate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    # Allow any user to create a template
    new_template = models.ProjectTemplate(
        user_id=current_user.id, name=template.name, settings=template.settings
    )
    db.add(new_template)
    db.commit()
    db.refresh(new_template)
    return new_template


@app.get("/templates", response_model=List[ProjectTemplateResponse])
def get_templates(
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    # Return user's templates AND system templates (user_id is NULL)
    return (
        db.query(models.ProjectTemplate)
        .filter(
            (models.ProjectTemplate.user_id == current_user.id)
            | (models.ProjectTemplate.user_id == None)
        )
        .order_by(models.ProjectTemplate.created_at.desc())
        .all()
    )


@app.delete("/templates/{template_id}")
def delete_template(
    template_id: str,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    template = (
        db.query(models.ProjectTemplate)
        .filter(models.ProjectTemplate.id == template_id)
        .first()
    )
    if not template:
        raise HTTPException(status_code=404, detail="Template not found")

    # Check ownership (Admins can delete any, users only their own)
    if current_user.role != "admin" and template.user_id != current_user.id:
        raise HTTPException(
            status_code=403, detail="Not authorized to delete this template"
        )

    db.delete(template)
    db.commit()
    return {"status": "deleted"}


# --- Ticket & Notification Endpoints ---


@app.get("/tickets", response_model=List[TicketResponse])
def get_tickets(
    db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)
):
    if current_user.role == "admin":
        return db.query(models.Ticket).all()
    return (
        db.query(models.Ticket).filter(models.Ticket.user_id == current_user.id).all()
    )


@app.post("/tickets", response_model=TicketResponse)
def create_ticket(
    ticket: TicketCreate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    new_ticket = models.Ticket(
        user_id=current_user.id,
        project_id=ticket.project_id,
        subject=ticket.subject,
        priority=ticket.priority,
        messages=ticket.messages,
    )
    db.add(new_ticket)

    # Notify admins of new ticket
    admins = db.query(models.User).filter(models.User.role == "admin").all()
    for admin in admins:
        new_notif = models.Notification(
            user_id=admin.id,
            title="New Support Ticket",
            message=f"User {current_user.email} created a new ticket: {ticket.subject}",
            type="info",
        )
        db.add(new_notif)

    db.commit()
    db.refresh(new_ticket)
    return new_ticket


@app.post("/tickets/{ticket_id}/reply", response_model=TicketResponse)
def reply_to_ticket(
    ticket_id: str,
    reply: TicketReply,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    ticket = db.query(models.Ticket).filter(models.Ticket.id == ticket_id).first()
    if not ticket:
        raise HTTPException(status_code=404, detail="Ticket not found")

    if current_user.role != "admin" and ticket.user_id != current_user.id:
        raise HTTPException(
            status_code=403, detail="Not authorized to reply to this ticket"
        )

    # Append new message to the JSON list
    new_message = {
        "id": str(uuid.uuid4()),
        "sender": reply.sender,
        "text": reply.text,
        "date": datetime.datetime.utcnow().isoformat(),
        "attachments": reply.attachments,
    }

    messages = list(ticket.messages) if ticket.messages else []
    messages.append(new_message)
    ticket.messages = messages

    # Auto-set status to 'open' if user replies to a closed ticket,
    # or 'in-progress' if admin replies
    if reply.sender == "admin":
        ticket.status = "in-progress"
        # Notify the user
        new_notif = models.Notification(
            user_id=ticket.user_id,
            title="Support Reply",
            message=f"New message from support on ticket: {ticket.subject}",
            type="info",
        )
        db.add(new_notif)
    elif reply.sender == "user":
        if ticket.status == "closed":
            ticket.status = "open"
        # Notify admins
        admins = db.query(models.User).filter(models.User.role == "admin").all()
        for admin in admins:
            new_notif = models.Notification(
                user_id=admin.id,
                title="New Ticket Message",
                message=f"User {current_user.email} replied to ticket: {ticket.subject}",
                type="info",
            )
            db.add(new_notif)

    db.commit()
    db.refresh(ticket)
    return ticket


@app.put("/tickets/{ticket_id}/status", response_model=TicketResponse)
def update_ticket_status(
    ticket_id: str,
    status_data: TicketStatusUpdate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    if current_user.role != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")

    ticket = db.query(models.Ticket).filter(models.Ticket.id == ticket_id).first()
    if not ticket:
        raise HTTPException(status_code=404, detail="Ticket not found")

    ticket.status = status_data.status
    db.commit()
    db.refresh(ticket)
    return ticket


@app.put("/tickets/{ticket_id}/priority", response_model=TicketResponse)
def update_ticket_priority(
    ticket_id: str,
    priority_data: TicketPriorityUpdate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    if current_user.role != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")

    ticket = db.query(models.Ticket).filter(models.Ticket.id == ticket_id).first()
    if not ticket:
        raise HTTPException(status_code=404, detail="Ticket not found")

    ticket.priority = priority_data.priority
    db.commit()
    db.refresh(ticket)
    return ticket


@app.delete("/tickets/{ticket_id}")
def delete_ticket(
    ticket_id: str,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    if current_user.role != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")

    ticket = db.query(models.Ticket).filter(models.Ticket.id == ticket_id).first()
    if not ticket:
        raise HTTPException(status_code=404, detail="Ticket not found")

    db.delete(ticket)
    db.commit()
    return {"status": "ok"}


@app.get("/notifications", response_model=List[NotificationResponse])
def get_notifications(
    db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)
):
    return (
        db.query(models.Notification)
        .filter(models.Notification.user_id == current_user.id)
        .order_by(models.Notification.created_at.desc())
        .all()
    )


@app.put("/notifications/{notif_id}/read")
def mark_notification_read(
    notif_id: str,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    notif = (
        db.query(models.Notification)
        .filter(
            models.Notification.id == notif_id,
            models.Notification.user_id == current_user.id,
        )
        .first()
    )
    if notif:
        notif.is_read = True
        db.commit()
    return {"status": "ok"}


@app.get("/settings")
def get_settings(db: Session = Depends(get_db)):
    settings_row = db.query(models.SystemSettings).first()
    if not settings_row:
        return {"settings": {}}
    return {"settings": settings_row.settings}


@app.put("/settings")
def update_settings(
    data: SystemSettingsUpdate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    if current_user.role != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")

    settings_row = db.query(models.SystemSettings).first()
    if not settings_row:
        settings_row = models.SystemSettings(id=1, settings=data.settings)
        db.add(settings_row)
    else:
        settings_row.settings = data.settings
    db.commit()
    return {"status": "updated"}


@app.post("/admin/system/traffic")
def set_global_traffic_status(
    enabled: bool,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    """Emergency Stop / Resume for all traffic"""
    if current_user.role != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")

    # 1. Update Scheduler directly
    scheduler.is_globally_paused = not enabled

    # 2. Persist to DB
    settings_row = db.query(models.SystemSettings).first()
    if not settings_row:
        # Create default if missing
        settings_row = models.SystemSettings(id=1, settings={})
        db.add(settings_row)

    # Ensure settings is a dict
    current_settings = dict(settings_row.settings) if settings_row.settings else {}
    current_settings["traffic_enabled"] = enabled

    # Force update
    settings_row.settings = current_settings
    # Flag modification for SQLAlchemy JSON types
    from sqlalchemy.orm.attributes import flag_modified

    flag_modified(settings_row, "settings")

    db.commit()

    status_msg = "Traffic RESUMED" if enabled else "Traffic PAUSED globally"
    return {"status": "success", "message": status_msg, "traffic_enabled": enabled}


async def scrape_url_for_ga(session, url, depth=0):
    """Recursive scraper for GA IDs"""
    if depth > 1:  # Only follow one level of external scripts
        return None

    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    }

    try:
        async with session.get(
            url, timeout=10, headers=headers, allow_redirects=True
        ) as response:
            if response.status != 200:
                return None

            content = await response.text()

            # 1. Look for G- IDs (The primary goal)
            g_match = re.search(r"G-[A-Z0-9]{8,14}", content)
            if g_match:
                return g_match.group(0)

            # 2. Look for UA- IDs
            ua_match = re.search(r"UA-\d+-\d+", content)
            if ua_match:
                return ua_match.group(0)

            # 3. Look for GT- or GTM- containers
            if depth == 0:
                # Standard GT- container
                gt_match = re.search(r"GT-[A-Z0-9]{7,14}", content)
                if gt_match:
                    gt_id = gt_match.group(0)
                    script_url = f"https://www.googletagmanager.com/gtag/js?id={gt_id}"
                    found_inner = await scrape_url_for_ga(
                        session, script_url, depth + 1
                    )
                    if found_inner:
                        return found_inner
                    return gt_id

                # GTM- container (often wraps GA4)
                gtm_match = re.search(r"GTM-[A-Z0-9]{7,14}", content)
                if gtm_match:
                    # We can't easily fetch GTM.js implementation without headless browser,
                    # but sometimes G- ID is just sitting in the GTM noscript or config.
                    # For now, if we found GTM but no G-, we might just return the GTM ID
                    # as a last resort or continue.
                    pass

            return None

            return None
    except Exception:
        return None


@app.get("/find-tid")
async def find_tid_endpoint(url: str):
    """Scrapes the given URL to find a Google Analytics Tracking ID (G- or UA-)"""
    # Basic validation
    if not url.startswith("http"):
        url = "https://" + url

    try:
        async with aiohttp.ClientSession() as session:
            found_id = await scrape_url_for_ga(session, url)

            if found_id:
                return {"tid": found_id}

            raise HTTPException(
                status_code=404,
                detail="No Google Analytics tag found on this page. Please enter it manually.",
            )

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Error accessing URL: {str(e)}")


@app.get("/sitemap.xml")
async def get_sitemap(request: Request):
    """Dynamically serves sitemap.xml with the correct domain"""
    sitemap_path = os.path.join(FRONTEND_PATH, "sitemap.xml")
    if not os.path.exists(sitemap_path):
        raise HTTPException(status_code=404, detail="Sitemap not found")

    with open(sitemap_path, "r") as f:
        content = f.read()

    # Replace placeholder/default domain with actual request base URL
    # We remove the trailing slash from base_url for cleaner concatenation
    base_url = str(request.base_url).rstrip("/")

    # Replace traffic-creator.com (our default) with the actual host
    # If the file has localhost, we replace that too just in case
    content = content.replace("https://traffic-creator.com", base_url)
    content = content.replace("http://localhost:3000", base_url)

    return Response(content=content, media_type="application/xml")


# --- Static Files / SPA Catch-all (Must be last) ---
if os.path.exists(FRONTEND_PATH):
    # Mount uploads separately to ensure it's not caught by SPA fallback
    UPLOADS_PATH = os.path.join(os.getcwd(), "static", "uploads")
    os.makedirs(UPLOADS_PATH, exist_ok=True)
    app.mount("/uploads", StaticFiles(directory=UPLOADS_PATH), name="uploads")

    app.mount(
        "/assets",
        StaticFiles(directory=os.path.join(FRONTEND_PATH, "assets")),
        name="assets",
    )

    @app.get("/{full_path:path}")
    async def serve_frontend(full_path: str):
        # Prevent API routes from being caught here if they don't match exactly
        # But since this is at the end, any registered routes will already be handled
        file_path = os.path.join(FRONTEND_PATH, full_path)
        if os.path.isfile(file_path):
            return FileResponse(file_path)
        return FileResponse(os.path.join(FRONTEND_PATH, "index.html"))
