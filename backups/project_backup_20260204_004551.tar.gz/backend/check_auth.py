import models
import database
from passlib.context import CryptContext

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

def verify_password(plain, hashed):
    return pwd_context.verify(plain, hashed)

db = database.SessionLocal()

# Check for admin user
print("=" * 60)
print("CHECKING ADMIN USER")
print("=" * 60)
user = db.query(models.User).filter(models.User.email == "admin@trafficcreator.com").first()

if user:
    print(f"User found: {user.email}")
    print(f"Role: {user.role}")
    print(f"Password hash: {user.password_hash[:50]}...")
    
    # Test different passwords
    passwords_to_test = ["admin123", "password123", "admin", "password", "123456"]
    for pwd in passwords_to_test:
        is_valid = verify_password(pwd, user.password_hash)
        print(f"Password '{pwd}' valid: {is_valid}")
        if is_valid:
            print(f"  --> CORRECT PASSWORD: '{pwd}'")
else:
    print("User 'admin@trafficcreator.com' NOT found.")
    print("\nAvailable users in database:")
    users = db.query(models.User).all()
    for u in users:
        print(f"  - {u.email} (role: {u.role})")
