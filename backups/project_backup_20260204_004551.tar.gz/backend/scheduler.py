import asyncio
import logging
import random
from datetime import datetime
from typing import Dict, Set
from sqlalchemy.orm import Session
from database import SessionLocal
import models
from hit_emulator import ga_emu_engine
import os

logger = logging.getLogger(__name__)

class TrafficScheduler:
    def __init__(self):
        self.is_running = False
        self._task = None
        self._running_tasks: Dict[str, asyncio.Task] = {}  # project_id -> Task
        self._completed_tasks: Set[asyncio.Task] = set()  # Tasks that have completed
        # Semaphore to limit concurrent project executions (default: 10 concurrent projects)
        self._max_concurrent = int(os.getenv("MAX_CONCURRENT_PROJECTS", "10"))
        self._semaphore = asyncio.Semaphore(self._max_concurrent)
        self._last_reset_date = None  # Track last daily reset to prevent duplicates

    async def start(self):
        if self.is_running:
            return
        self.is_running = True
        self._task = asyncio.create_task(self._loop())
        logger.info("SaaS Traffic Scheduler started")

    async def stop(self):
        self.is_running = False
        
        # Cancel all running project tasks
        if self._running_tasks:
            logger.info(f"Cancelling {len(self._running_tasks)} running project tasks...")
            for project_id, task in list(self._running_tasks.items()):
                task.cancel()
            
            # Wait for all tasks to complete cancellation
            if self._running_tasks:
                await asyncio.gather(*self._running_tasks.values(), return_exceptions=True)
            self._running_tasks.clear()
        
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        logger.info("SaaS Traffic Scheduler stopped")

    def _task_done_callback(self, project_id: str, task: asyncio.Task):
        """Callback to handle task completion and exception logging"""
        self._completed_tasks.discard(task)
        
        # Remove from running tasks if it's still there (might have been replaced)
        if project_id in self._running_tasks and self._running_tasks[project_id] is task:
            del self._running_tasks[project_id]
        
        # Check for exceptions
        try:
            task.result()
        except asyncio.CancelledError:
            logger.debug(f"Task for project {project_id} was cancelled")
        except Exception as e:
            logger.error(f"Task for project {project_id} failed with exception: {e}", exc_info=True)

    async def _loop(self):
        while self.is_running:
            try:
                await self.check_and_run()
            except Exception as e:
                logger.error(f"Error in scheduler loop: {e}")
            await asyncio.sleep(60) # Pulse every minute

    async def check_and_run(self):
        db = SessionLocal()
        try:
            now = datetime.utcnow()
            
            # 1. Daily Reset at Midnight (UTC)
            # Use date tracking to ensure reset happens only once per day
            current_date = now.date()
            if now.hour == 0 and now.minute == 0 and self._last_reset_date != current_date:
                self._last_reset_date = current_date
                db.query(models.Project).update({models.Project.hits_today: 0})
                db.commit()
                logger.info("Daily project hits reset to zero")

            # 2. Find All Active Projects
            active_projects = db.query(models.Project).filter(models.Project.status == "active").all()
            
            for project in active_projects:
                # Quota Check
                if project.daily_limit > 0 and project.hits_today >= project.daily_limit:
                    logger.debug(f"Project {project.id} ({project.name}) reached daily limit: {project.hits_today}/{project.daily_limit}")
                    continue

                if project.total_target > 0 and project.total_hits >= project.total_target:
                    logger.info(f"Project {project.id} ({project.name}) reached total target: {project.total_hits}/{project.total_target}. Completing...")
                    project.status = "completed"
                    db.commit()
                    continue

                # Check Expiry
                if project.expires_at and now > project.expires_at:
                    project.status = "completed"
                    db.commit()
                    continue

                # Run Burst - with proper task tracking and exception handling
                # Cancel any existing task for this project to prevent overlap
                if project.id in self._running_tasks:
                    old_task = self._running_tasks[project.id]
                    if not old_task.done():
                        old_task.cancel()
                        self._completed_tasks.add(old_task)
                
                # Create new task with exception handling
                task = asyncio.create_task(
                    self._run_project_with_error_handling(project.id, project.name)
                )
                task.add_done_callback(
                    lambda t, pid=project.id: self._task_done_callback(pid, t)
                )
                self._running_tasks[project.id] = task
        except Exception as e:
            logger.error(f"Scheduler check failed: {e}")
        finally:
            db.close()

    async def _run_project_with_error_handling(self, project_id: str, project_name: str):
        """Wrapper to run project engine with proper error handling and semaphore control"""
        async with self._semaphore:
            try:
                logger.debug(f"Starting engine run for project {project_id} ({project_name})")
                await ga_emu_engine.run_for_project(project_id)
                logger.debug(f"Completed engine run for project {project_id} ({project_name})")
            except asyncio.CancelledError:
                logger.debug(f"Project {project_id} ({project_name}) task was cancelled")
                raise  # Re-raise to properly signal cancellation
            except Exception as e:
                logger.error(f"Engine run failed for project {project_id} ({project_name}): {e}", exc_info=True)
                raise

scheduler = TrafficScheduler()
