# 🚦 Feature Analysis & Sync Report

**Date:** 2026-01-28
**Scope:** Frontend Admin Panel vs. Traffic Generator Backend
**Status:** ⚠️ Significant Discrepancies Detected

---

## 📊 1. Executive Summary

Our analysis reveals that the **Frontend (User Interface)** offers significantly more features and granular control than the **Backend (Traffic Logic)** currently supports.

### 🎯 Intended System Design (Clarified)
The goal is a **Multi-User SaaS** where:
*   Users have private dashboards to manage **Multiple Projects**.
*   **Constraint**: 1 Project = 1 Domain (Target Website).
*   **Depth**: Unlimited subpages (funnels) within that domain, with a **Max Depth of 10 pages** per visitor session.
*   **Precision**: Users set a precise **Daily Visitor Count** (e.g., 5,000 visitors/day), which the system must **distribute evenly** over 24 hours (or specified active hours).

---

## 🔍 2. Feature Gap Matrix

| Feature | Requirement / Website UI | Generator Backend / Current State | Status |
| :--- | :--- | :--- | :--- |
| **Project Structure** | 📝 1 Domain per Project, Unlimited Subpages | 🛑 Single URL support | ⚠️ **Partial Match** |
| **Session Depth** | � Max 10 Pages (Funnel Steps) per Visitor | 🛑 Single Funnel support | ⚠️ **Partial Match** |
| **Speed Control** | ⏱️ **Fixed**: Precise "Visitors Per Day" (Evenly Distributed) | 💨 **Broken**: Abstract "Speed" (0-100%) slider behavior | ❌ **Critical Mismatch** |
| **Traffic Source** | � Custom UTM Tags (Source, Medium) | � No UTM support (Referrers only) | ❌ **Missing Feature** |
| **Device Targeting** | � Desktop / Tablet / Mobile % | � Simple Mobile vs. Desktop split | ❌ **Mismatch** |
| **Geo-Location** | 🌍 Single Country selection | 🌍 Weighted Country Lists | ⚠️ **Partial Match** |
| **Behavior** | ↩️ Explicit Bounce Rate % | 🤖 Implied by funnel logic | ⚠️ **Partial Match** |

---

## 🛠️ 3. Implementation Requirements

To match the clarified requirements, the following technical changes are mandatory:

### 🚨 Critical Fixes (Priority 1)

1.  **Refactor Volume Control (Token Bucket System)**:
    *   **Current**: Unpredictable "Speed" loop.
    *   **Required**: A "Pacer" system.
    *   *Logic*: If User sets `1440` visitors/day → System calculates `1 visitor / minute`. The engine must wake up exactly once per minute to trigger a session.

2.  **Enforce Project Constraints**:
    *   Ensure Backend enforces "1 Domain" per project but iterates through the defined "Funnel" list (up to 10 steps).

3.  **UTM & Tagging Support**:
    *   Update `GAEmuEngine` to accept and append `utm_source`, `utm_medium`, and `utm_campaign` to every hit in the session.

### ✅ High Feasibility (Standard Dev Work)
*   **Tablet Support**: Add "Tablet" user agents to the rotation.
*   **Custom Referrers**: Update logic to accept a specific URL as a referrer.

### ❌ Not Feasible (Requires New Architecture)
*   **Real User Interactions**: Scrolling, Clicking, Heatmaps (Requires Headless Browser).
*   **JavaScript Execution**: Pixel firing, anti-bot scripts (Requires Headless Browser).

---

## 📝 4. Recommendations

1.  **Immediate Action**: Abandon the `trafficSpeed` (0-100) logic. Replace it with a **Scheduled Dispatcher** that calculates `delay = (24h / daily_target)` and fires tasks accordingly.
2.  **Frontend Adjustment**: Simplify the UI to enforce the "1 Domain per Project" rule if it currently allows multiple disparate domains.
3.  **Backend Patch**: Add the UTM parameter logic immediately as it is a low-hanging fruit for high value.
